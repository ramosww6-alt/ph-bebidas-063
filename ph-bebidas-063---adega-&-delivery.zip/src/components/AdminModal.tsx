import React, { useState } from 'react';
import { Product, CategoryId } from '../types/adega';
import { CATEGORIES } from '../data/initialCatalog';
import { X, Settings, Plus, Edit2, Lock, Upload, Image as ImageIcon, Check, Trash2, Camera } from 'lucide-react';

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onUpdateProduct: (product: Product) => void;
  onAddProduct: (product: Product) => void;
  onDeleteProduct?: (productId: string) => void;
}

const PRESET_IMAGES = [
  { label: 'Cervejas Geladas', path: '/src/assets/images/cerveja_trincando_grid_1793883750481.jpg' },
  { label: 'Banner Balada', path: '/src/assets/images/hero_adega_bebidas_1793883749865.jpg' },
  { label: 'Kit Whisky', path: '/src/assets/images/combo_whisky_kit_1793883751151.jpg' },
  { label: 'Gin & Vodkas', path: '/src/assets/images/destilados_gin_vodka_1793883751112.jpg' },
  { label: 'Vinhos & Espumantes', path: '/src/assets/images/vinhos_nacionais_importados_1793883751799.jpg' },
];

export const AdminModal: React.FC<AdminModalProps> = ({
  isOpen,
  onClose,
  products,
  onUpdateProduct,
  onAddProduct,
  onDeleteProduct,
}) => {
  const [pinInput, setPinInput] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);

  // Form state for creating or editing
  const [formData, setFormData] = useState<Partial<Product>>({
    name: '',
    category: 'cervejas',
    price: 9.90,
    volume: '330ml',
    description: '',
    image: '/src/assets/images/cerveja_trincando_grid_1793883750481.jpg',
    isGelada: true,
    stockStatus: 'in_stock',
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput === '0630' || pinInput === '1234' || pinInput === 'admin') {
      setIsAuthenticated(true);
    } else {
      alert('PIN incorreto. Dica de senha de teste: 0630 ou 1234');
    }
  };

  // Image Upload handler via FileReader (Data URL)
  const handleImageFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert('A imagem é muito grande. Escolha uma imagem de até 5MB.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setFormData((prev) => ({ ...prev, image: reader.result as string }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.price) {
      alert('Por favor, informe o nome e o preço da bebida.');
      return;
    }

    if (editingProductId) {
      // Updating existing item
      const existing = products.find((p) => p.id === editingProductId);
      if (existing) {
        const updated: Product = {
          ...existing,
          name: formData.name,
          category: (formData.category as CategoryId) || existing.category,
          price: Number(formData.price),
          volume: formData.volume || existing.volume,
          description: formData.description || existing.description,
          image: formData.image || existing.image,
          isGelada: formData.isGelada ?? existing.isGelada,
          stockStatus: (formData.stockStatus as any) || existing.stockStatus,
        };
        onUpdateProduct(updated);
        alert(`Bebida "${updated.name}" atualizada com sucesso!`);
      }
      setEditingProductId(null);
    } else {
      // Creating new item
      const created: Product = {
        id: `custom-${Date.now()}`,
        name: formData.name,
        category: (formData.category as CategoryId) || 'cervejas',
        description: formData.description || 'Bebida cadastrada pela gerência.',
        price: Number(formData.price),
        volume: formData.volume || '1 Unidade',
        image: formData.image || '/src/assets/images/cerveja_trincando_grid_1793883750481.jpg',
        isGelada: !!formData.isGelada,
        stockStatus: (formData.stockStatus as any) || 'in_stock',
      };
      onAddProduct(created);
      alert(`Nova bebida "${created.name}" adicionada ao estoque!`);
    }

    // Reset form
    setFormData({
      name: '',
      category: 'cervejas',
      price: 9.90,
      volume: '330ml',
      description: '',
      image: '/src/assets/images/cerveja_trincando_grid_1793883750481.jpg',
      isGelada: true,
      stockStatus: 'in_stock',
    });
  };

  const startEditProduct = (p: Product) => {
    setEditingProductId(p.id);
    setFormData({
      name: p.name,
      category: p.category,
      price: p.price,
      volume: p.volume,
      description: p.description,
      image: p.image,
      isGelada: p.isGelada,
      stockStatus: p.stockStatus,
    });
  };

  const cancelEdit = () => {
    setEditingProductId(null);
    setFormData({
      name: '',
      category: 'cervejas',
      price: 9.90,
      volume: '330ml',
      description: '',
      image: '/src/assets/images/cerveja_trincando_grid_1793883750481.jpg',
      isGelada: true,
      stockStatus: 'in_stock',
    });
  };

  const handleToggleStock = (product: Product) => {
    const nextStatus = product.stockStatus === 'in_stock' ? 'out_of_stock' : 'in_stock';
    onUpdateProduct({ ...product, stockStatus: nextStatus });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-3xl bg-zinc-950 border border-amber-500/40 rounded-2xl p-4 sm:p-6 text-white max-h-[92vh] flex flex-col justify-between shadow-2xl">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/40">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold font-display text-white">Painel de Gerência PH BEBIDAS</h2>
              <p className="text-[11px] text-zinc-400">Adicione produtos e altere fotos das bebidas</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-zinc-400 hover:text-white rounded-lg bg-zinc-900 border border-zinc-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {!isAuthenticated ? (
          <form onSubmit={handleLogin} className="py-12 max-w-xs mx-auto text-center space-y-4">
            <div className="w-12 h-12 mx-auto rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/40">
              <Lock className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white font-display">Acesso de Gerente</h3>
            <p className="text-xs text-zinc-400">
              Digite o PIN para gerenciar estoque e trocar fotos de bebidas (Senha de teste: <span className="font-mono text-amber-400 font-bold">0630</span>).
            </p>
            <input
              type="password"
              placeholder="Digite 0630"
              value={pinInput}
              onChange={(e) => setPinInput(e.target.value)}
              className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-xl text-center font-mono text-lg tracking-widest text-white focus:outline-none focus:border-amber-500"
            />
            <button
              type="submit"
              className="w-full py-2.5 bg-amber-500 text-zinc-950 font-bold text-xs rounded-xl hover:bg-amber-400 transition-colors"
            >
              Entrar no Painel
            </button>
          </form>
        ) : (
          <div className="flex-1 overflow-y-auto py-4 space-y-6">
            
            {/* Create/Edit Product Form with Photo Uploader */}
            <form onSubmit={handleSaveProduct} className="p-4 sm:p-5 bg-zinc-900 border border-amber-500/30 rounded-2xl space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
                <h3 className="text-xs sm:text-sm font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                  {editingProductId ? <Edit2 className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                  {editingProductId ? 'Editar Bebida & Trocar Foto' : 'Cadastrar Nova Bebida com Foto'}
                </h3>
                {editingProductId && (
                  <button
                    type="button"
                    onClick={cancelEdit}
                    className="text-xs text-zinc-400 hover:text-white underline"
                  >
                    Cancelar Edição
                  </button>
                )}
              </div>

              {/* Photo Upload Section */}
              <div className="space-y-3 bg-zinc-950 p-3.5 rounded-xl border border-zinc-800">
                <label className="block text-xs font-bold text-zinc-300 flex items-center gap-1.5">
                  <Camera className="w-4 h-4 text-amber-400" /> Foto da Bebida *
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center">
                  {/* Photo Preview */}
                  <div className="sm:col-span-4 flex flex-col items-center justify-center p-2 bg-zinc-900 rounded-xl border border-zinc-800 h-32 relative group">
                    {formData.image ? (
                      <img
                        src={formData.image}
                        alt="Preview"
                        className="w-full h-full object-contain rounded-lg"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="text-center text-zinc-600">
                        <ImageIcon className="w-8 h-8 mx-auto" />
                        <span className="text-[10px]">Sem foto</span>
                      </div>
                    )}
                    <span className="absolute bottom-1 right-1 text-[9px] bg-zinc-950/90 text-amber-400 px-1.5 py-0.5 rounded border border-zinc-700">
                      Pré-visualização
                    </span>
                  </div>

                  {/* Photo Upload Options */}
                  <div className="sm:col-span-8 space-y-2">
                    {/* File Input button */}
                    <div>
                      <label className="cursor-pointer inline-flex items-center gap-2 px-3 py-2 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs rounded-xl transition-all shadow-md shadow-amber-500/10">
                        <Upload className="w-4 h-4" />
                        <span>Carregar Foto do Aparelho / Galeria</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleImageFileUpload}
                          className="hidden"
                        />
                      </label>
                      <p className="text-[10px] text-zinc-500 mt-1">
                        Selecione qualquer imagem (JPG, PNG) do seu celular ou computador.
                      </p>
                    </div>

                    {/* Image URL fallback */}
                    <div>
                      <label className="block text-[11px] text-zinc-400 mb-0.5">Ou Cole a URL / Link da Foto:</label>
                      <input
                        type="text"
                        placeholder="https://exemplo.com/foto-cerveja.jpg"
                        value={formData.image}
                        onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-zinc-900 border border-zinc-800 rounded-lg text-xs text-white font-mono placeholder-zinc-600"
                      />
                    </div>

                    {/* Presets */}
                    <div>
                      <label className="block text-[10px] text-zinc-500 mb-1">Ou Escolha um Preset:</label>
                      <div className="flex flex-wrap gap-1.5">
                        {PRESET_IMAGES.map((preset, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => setFormData({ ...formData, image: preset.path })}
                            className="text-[10px] px-2 py-0.5 rounded bg-zinc-800 hover:bg-amber-500/20 hover:text-amber-300 text-zinc-400 border border-zinc-700"
                          >
                            {preset.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Product Info Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-zinc-400">Nome da Bebida *</label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: Cerveja Spaten Latão 473ml"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-2.5 py-1.5 bg-zinc-950 border border-zinc-800 rounded-lg text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-zinc-400">Categoria *</label>
                  <select
                    value={formData.category}
                    onChange={(e: any) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-2.5 py-1.5 bg-zinc-950 border border-zinc-800 rounded-lg text-xs text-white"
                  >
                    {CATEGORIES.filter((c) => c.id !== 'todos').map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] text-zinc-400">Preço (R$) *</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    placeholder="7.99"
                    value={formData.price || ''}
                    onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) })}
                    className="w-full px-2.5 py-1.5 bg-zinc-950 border border-zinc-800 rounded-lg text-xs text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-zinc-400">Volume / Embalagem *</label>
                  <input
                    type="text"
                    placeholder="Ex: 350ml, 1 Litro, Pack 6 un"
                    value={formData.volume}
                    onChange={(e) => setFormData({ ...formData, volume: e.target.value })}
                    className="w-full px-2.5 py-1.5 bg-zinc-950 border border-zinc-800 rounded-lg text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-zinc-400">Descrição Curta</label>
                <input
                  type="text"
                  placeholder="Ex: Cerveja puro malte estupidamente gelada."
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-2.5 py-1.5 bg-zinc-950 border border-zinc-800 rounded-lg text-xs text-white"
                />
              </div>

              <div className="flex items-center gap-4 text-xs pt-1">
                <label className="flex items-center gap-1.5 cursor-pointer text-zinc-300">
                  <input
                    type="checkbox"
                    checked={formData.isGelada}
                    onChange={(e) => setFormData({ ...formData, isGelada: e.target.checked })}
                    className="accent-amber-500 rounded"
                  />
                  <span>🧊 Temperatura Gelada</span>
                </label>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  {editingProductId ? 'Salvar Alterações da Bebida' : 'Cadastrar Bebida no Estoque'}
                </button>
              </div>
            </form>

            {/* Inventory List with "Editar Foto" Buttons */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center justify-between">
                <span>Estoque de Bebidas Cadastradas ({products.length})</span>
                <span className="text-[10px] text-amber-400">Clique em "Editar Foto" para alterar</span>
              </h3>

              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {products.map((p) => (
                  <div
                    key={p.id}
                    className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl flex items-center justify-between gap-3 text-xs hover:border-zinc-700"
                  >
                    <div className="flex items-center gap-3 overflow-hidden">
                      <img
                        src={p.image}
                        alt={p.name}
                        className="w-10 h-10 object-contain bg-zinc-950 rounded-lg p-0.5 shrink-0 border border-zinc-800"
                        referrerPolicy="no-referrer"
                      />
                      <div className="overflow-hidden">
                        <div className="font-bold text-white truncate">{p.name}</div>
                        <div className="text-[11px] text-zinc-400 font-mono">
                          R$ {p.price.toFixed(2)} · {p.volume}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => startEditProduct(p)}
                        className="px-2.5 py-1.5 rounded-lg text-[11px] font-bold bg-amber-500/20 text-amber-400 hover:bg-amber-500/30 border border-amber-500/40 flex items-center gap-1 transition-colors"
                      >
                        <Camera className="w-3 h-3" />
                        <span>Editar Foto</span>
                      </button>

                      <button
                        onClick={() => handleToggleStock(p)}
                        className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition-colors ${
                          p.stockStatus === 'in_stock'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                            : 'bg-red-500/20 text-red-400 border border-red-500/40'
                        }`}
                      >
                        {p.stockStatus === 'in_stock' ? 'Em Estoque' : 'Esgotado'}
                      </button>

                      {onDeleteProduct && (
                        <button
                          onClick={() => {
                            if (confirm(`Remover "${p.name}" do estoque?`)) {
                              onDeleteProduct(p.id);
                            }
                          }}
                          className="p-1.5 text-zinc-500 hover:text-red-400 rounded-lg"
                          title="Excluir produto"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
